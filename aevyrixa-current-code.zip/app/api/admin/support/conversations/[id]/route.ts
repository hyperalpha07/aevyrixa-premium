import { forbiddenAdminResponse, verifyFreshAdminRequestPermission } from "@/app/lib/admin-auth";
import { logStaffActivity } from "@/app/lib/admin-staff";
import {
  getConversationById,
  getMessagesByConversation,
  markCustomerMessagesRead,
  updateConversationStatus,
  type ConversationStatus,
} from "@/app/lib/support-store";

export const dynamic = "force-dynamic";

function json(payload: unknown, init: ResponseInit = {}) {
  const headers = new Headers(init.headers);
  headers.set("cache-control", "no-store");
  return Response.json(payload, { ...init, headers });
}

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!(await verifyFreshAdminRequestPermission(request, "support.view"))) return forbiddenAdminResponse();

  const { id } = await params;
  const url = new URL(request.url);
  const shouldMarkRead = url.searchParams.get("markRead") === "1";

  try {
    const conversation = await getConversationById(id);
    if (!conversation) return json({ error: "Conversation not found." }, { status: 404 });

    const messages = await getMessagesByConversation(id);
    if (shouldMarkRead) {
      markCustomerMessagesRead(id).catch(() => null);
    }

    return json({
      id: conversation.id,
      status: conversation.status,
      source_page: conversation.source_page,
      created_at: conversation.created_at,
      updated_at: conversation.updated_at,
      messages: messages.map((m) => ({
        id: m.id,
        body: m.body,
        sender_type: m.sender_type,
        created_at: m.created_at,
      })),
    });
  } catch (error) {
    console.error("Failed to load admin conversation:", error);
    return json({ error: "Could not load conversation." }, { status: 503 });
  }
}

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const session = await verifyFreshAdminRequestPermission(request, "support.close");
  if (!session) return forbiddenAdminResponse();

  const { id } = await params;

  let status: ConversationStatus;
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const s = body.status;
    if (s !== "open" && s !== "pending" && s !== "closed") {
      return json({ error: "Invalid status. Use open, pending, or closed." }, { status: 400 });
    }
    status = s;
  } catch {
    return json({ error: "Invalid request body." }, { status: 400 });
  }

  try {
    await updateConversationStatus(id, status);
    await logStaffActivity({
      actor: session,
      action: "support.status_updated",
      targetType: "conversation",
      targetId: id,
      metadata: { status },
    });
    return json({ ok: true, status });
  } catch (error) {
    console.error("Failed to update conversation status:", error);
    return json({ error: "Could not update status." }, { status: 503 });
  }
}
